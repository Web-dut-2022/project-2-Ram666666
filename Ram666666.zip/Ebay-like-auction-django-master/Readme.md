**Installation

Run these commands in the terminal

1.pip install django
2.python manage.py makemigrations
3.python manage.py migrate
4.python manage.py runserver